<?php

/**
 * @Project NUKEVIET 4.x
 * @This product includes GeoLite2 data created by MaxMind, available from http://www.maxmind.com
 * @Createdate Wed, 18 Apr 2018 03:19:55 GMT
 */

$ranges=array(318767104=>array(322058771,'US'),322058772=>array(322058772,'CL'),322058773=>array(335544319,'US'));
